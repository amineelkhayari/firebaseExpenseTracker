
export const users:Participants[]  = [
    {
        ID: 1,
        Value: "Amine",
        checked: false,
        Payed: false
      },
      {
        ID: 2,
        Value: "Mohammed",
        checked: false,
        Payed: false
      },
      {
        ID: 3,
        Value: "Jounir",
        checked: false,
        Payed: false
      },
      {
        ID: 4,
        Value: "Harari",
        checked: false,
        Payed: false,
      }
  ];
  