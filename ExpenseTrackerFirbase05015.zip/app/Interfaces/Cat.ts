type Category={
    ID:number,
    Value:string
}
const category:Category[] =[
    {
        ID:1,
        Value:"Food"
    },
    {
        ID:2,
        Value:"Home"
    },{
        ID:3,
        Value:"Transport"
    },{
        ID:4,
        Value:"Others"
    }
];
export {category};